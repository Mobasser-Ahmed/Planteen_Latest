package app;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.UserController;
import controller.ValidationController;
import entity.User;
import jdk.nashorn.internal.ir.RuntimeNode.Request;
import model.UserRepository;

/**
 * Servlet implementation class UserProfileServlet
 */
@WebServlet("/UserProfile")
public class UserProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//RequestDispatcher dispatcher= request.getRequestDispatcher("userProfileSettings.jsp");
		
		
		int id= 1;
		System.out.println("this is id"+ id);
		User user= new UserController().getById(id);
		System.out.println(user.getName());
		request.setAttribute("user", user);
		
		
		RequestDispatcher dispatcher= request.getRequestDispatcher("userProfileSettings.jsp");
		
		
		dispatcher.forward(request, response);
	}



	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		
		int userId=1;/// will come from session
		String name=request.getParameter("txt_name").trim();
		String email=request.getParameter("txt_email").trim();
		String gender=request.getParameter("txt_gender").trim();
		String address=request.getParameter("txt_address").trim();
		String phone=request.getParameter("txt_phone".trim());
		User user = new User(userId,name, email, address, phone, gender);
		
		
		
		///======add validation before update the use=============
		
		
		// added by nabila starts
		request.setAttribute("txt_name", name);
        request.setAttribute("txt_email", email);
        request.setAttribute("txt_gender", gender);
        request.setAttribute("txt_address", address);
        request.setAttribute("txt_phone", phone);
        
        RequestDispatcher dispatcher= null;
        boolean check=true;
        boolean temp;
        
        temp = ValidationController.checkAddress(address);
        check = check & temp;
        temp = ValidationController.checkPhoneNumber(phone);
        check = check & temp;
        
        request.setAttribute("err_address", ValidationController.err_address);
        request.setAttribute("err_phone", ValidationController.err_phone);
       
        
        
        
        
		// added by nabila ends
		
        if(check){
			new UserController().editByUser(user);
			System.out.println("updated");
			
			request.setAttribute("user", user);
			dispatcher= request.getRequestDispatcher("userProfileSettings.jsp");
			dispatcher.forward(request, response);
        }
        else{
        	user=new UserRepository().getById(userId);
        	request.setAttribute("user", user);
			dispatcher= request.getRequestDispatcher("userProfileSettings.jsp");
			dispatcher.forward(request, response);
        }
     
		
	}
	

	
	

}
